#include <iostream>
#include "Number.hpp"

template <int B, int N>
void testNumber(int v1,int v2)
{
    Number <B,N> N1(v1),N2(v2);

    try
    {
    std::cout<<std::endl<<"Base "<<B<<std::endl<<"1 valor: ";
    N1.write(std::cout);
    std::cout<<"2 valor: ";
    N2.write(std::cout);
    std::cout<<"Suma: ";
    N1.suma(N2).write(std::cout);
    // op=N1.multiplicacion(N2);
    // std::cout<<"Multiplicacion: ";
    // op.write(std::cout);
    //std::cout<<std::endl;
    }
    catch (Overflow& e)
    {
        (Number<B,N+1>(N1).suma(Number<B,N+1>(N2))).write(std::cout);
    }
}

int main() 
{
    
        int val1=0,val2=0;

        std::cout<< "Introduzca 1 numero: ";
        std::cin>>val1;
        std::cout<< "Introduzca 2 numero: ";
        std::cin>>val2;

    try
    {
        testNumber<2,5> (val1,val2);
    }
    catch (NumberExeption& e)
	{
		std::cout << e.what() << std::endl;
	} 
    
    try
    {
        testNumber<10,5> (val1,val2);
    }
    catch (NumberExeption& e)
	{
		std::cout << e.what() << std::endl;
	}
       
    try
    {
        testNumber<16,5> (val1,val2);
    }
    catch (NumberExeption& e)
	{
		std::cout << e.what() << std::endl;
	}
        
    return 0;  
}

/*
desde el programa principal, si se genera overflow al numero contenedor se le aumenta el tamaño
*/