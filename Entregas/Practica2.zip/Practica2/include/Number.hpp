#pragma once

#include <ostream>

template<int B, int N, class T=unsigned char>
class Number 
{
private:
    T* num;
    int signo=1;
    void to_base(int val);//convierte entero en la base pedida

public:
    Number(int val=0);
    ~Number(); 
    Number<B,N,T> suma(const Number<B,N,T>& op)const;
    std::ostream& write(std::ostream& os)const;
    Number<B,N,T>& operator =(const Number<B,N,T>& copy);
    operator Number<B,N+1,T> ( )const;
    int mayor(const Number<B,N,T>& op)const;
    void set_val(int x, int pos);
    void set_sig(int x);
    //Number<B,N,T> multiplicacion(const Number<B,N,T>& op)const;
};

template<int N, class T>
class Number <2,N,T>
{
private:
    T* num;
    int signo=1;
    void to_base(int val);//convierte entero en la base pedida
    void complementador();//transforma a complemento a 2

public:
    Number(int val=0);
    ~Number(); 
    Number<2,N,T> suma(const Number<2,N,T>& op)const; 
    std::ostream& write(std::ostream& os)const;
    Number<2,N,T>& operator =(const Number<2,N,T>& copy);  
    operator Number<2,N+1,T> ( )const;
    void set_val(int x, int pos);
    void set_sig(int x);
};

#include "../src/Number.tpp"